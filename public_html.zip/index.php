<!DOCTYPE html>
<html lang="es">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/page.css">
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300&family=Noto+Sans&family=Poppins:wght@300&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/989f8affb2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&family=Nunito+Sans:ital,opsz,wght@0,6..12,200..1000;1,6..12,200..1000&display=swap" rel="stylesheet">
    <link rel="icon" href="img/santeLogo.jpg">
    <title>Sante</title>
    <style>
        body {
            background-color: #F6EBD5 !important;
        }

        .logoSante {
            width: 120px;
            height: 120px;
            position: absolute;
            top: 65%;
            left: 8%;
        }

        .logoSante img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .slider {
            width: 260px;
            height: 260px;
            overflow: hidden;
        }

        .carousel-inner {
            width: 260px;
            height: 260px;
        }

        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        @media (max-width: 991px) {
            .logoSante {
                display: none;
            }
        }

        @media (max-width: 375px) {
            .carousel-inner {
            width: 200px;
            height: 200px;
            }


            .principal_links {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <section class="principal_contianerIndex">
        <div class="text_principal">
            <div class="links_principales">
                <a href="pages/convenios.php"><button>CONVENIOS ACTIVOS</button></a>
                <a href="pages/informacion.php"><button>QUIENES SOMOS</button></a>
            </div>
            <h5>Bienvenidos a</h5>
            <h2>SANTÉ, CENTRO <br> DE SALUD</h2>
        </div>
        <div class="slider_principal">
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel" data-bs-interval="3000">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="slider carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/santefrente.jpg" class="d-block w-100" alt="Slide 1">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider1.jpg" class="d-block w-100" alt="Slide 2">
                    </div>
                    <div class="carousel-item">
                        <img src="img/profesionalesIMG.jpg" class="d-block w-100" alt="Slide 3">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="principal_links">
        <a target="_blank" href="https://www.google.com.ar/maps/place/CLO,+Zapiola+723,+B8000+Bah%C3%ADa+Blanca,+Provincia+de+Buenos+Aires/@-38.7080511,-62.2711708,17z/data=!3m1!4b1!4m6!3m5!1s0x95edbb56073f7897:0xc3b58c5fc9707514!8m2!3d-38.7080553!4d-62.2685959!16s%2Fg%2F11fnwc3n77?hl=es&entry=ttu&g_ep=EgoyMDI1MDQwOC4wIKXMDSoASAFQAw%3D%3D"><button><i class="fa-solid fa-location-dot"></i> Zapiola 723 - Bahia Blanca</button></a>
        <a target="_blank" href="https://wa.me/5492915204351"><button><i class="fa-brands fa-whatsapp"></i> 2915204351</button></a>
        <a target="_blank" href="https://www.instagram.com/santecentrodesalud/"><button><i class="fa-brands fa-instagram"></i> SANTECENTRODESALUD</button></a>
    </section>
    <div class="logoSante">
        <img src="img/santeLogo.jpg" alt="">
    </div>
    <a class="solicitar_turno" href="servicios.php"><button>Solicitar un Turno</button></a>
</body>
</html>