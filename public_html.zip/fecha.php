<?php
session_start();

// En entorno de prueba/desarrollo, usamos un enfoque basado en memoria
// Esta es una simulación para probar la funcionalidad. 
// En producción, esto sería reemplazado por una conexión real a la base de datos

class MockDatabase {
    private $tables = [];
    
    public function __construct() {
        // Inicializar tablas mock
        $this->tables['profesionales_deshabilitados'] = [];
        $this->tables['profesionales_dias_deshabilitados'] = [];
        $this->tables['turnos'] = [];
        
        // Si hay datos en la sesión, restaurarlos
        if (isset($_SESSION['mock_db'])) {
            $this->tables = $_SESSION['mock_db'];
        }
    }
    
    public function prepare($query) {
        return new MockStatement($this, $query);
    }
    
    public function query($query) {
        // Implementación simple solo para CREATE TABLE
        if (stripos($query, 'CREATE TABLE IF NOT EXISTS') !== false) {
            return true; // Pretender que la tabla se creó
        }
        return false;
    }
    
    public function getTable($tableName) {
        return isset($this->tables[$tableName]) ? $this->tables[$tableName] : [];
    }
    
    public function insert($table, $data) {
        if (!isset($this->tables[$table])) {
            $this->tables[$table] = [];
        }
        
        // Asignar un ID auto-incrementado
        $id = count($this->tables[$table]) + 1;
        $data['id'] = $id;
        
        $this->tables[$table][] = $data;
        
        // Guardar en sesión
        $_SESSION['mock_db'] = $this->tables;
        
        return true;
    }
    
    public function select($table, $condition = []) {
        if (!isset($this->tables[$table])) return [];
        
        $result = [];
        foreach ($this->tables[$table] as $row) {
            $match = true;
            foreach ($condition as $key => $value) {
                // Manejo especial para LIKE
                if (is_array($value) && isset($value['operator']) && $value['operator'] === 'LIKE') {
                    $pattern = str_replace('%', '.*', $value['value']);
                    if (!preg_match('/^' . $pattern . '$/', $row[$key])) {
                        $match = false;
                        break;
                    }
                } 
                // Igualdad simple
                else if (!isset($row[$key]) || $row[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            
            if ($match) $result[] = $row;
        }
        
        return $result;
    }
}

class MockStatement {
    private $db;
    private $query;
    private $params = [];
    private $bind_result_vars = [];
    private $lastResult = null;
    
    public function __construct($db, $query) {
        $this->db = $db;
        $this->query = $query;
    }
    
    public function bind_param($types, ...$params) {
        $this->params = $params;
        return true;
    }
    
    public function bind_result(&$var1, &$var2 = null) {
        $this->bind_result_vars = [];
        $this->bind_result_vars[] = &$var1;
        if ($var2 !== null) $this->bind_result_vars[] = &$var2;
        return true;
    }
    
    public function fetch() {
        // Simulación simple para SELECT COUNT(*)
        if (stripos($this->query, 'SELECT deshabilitado FROM profesionales_deshabilitados') !== false) {
            if (!empty($this->bind_result_vars)) {
                $this->bind_result_vars[0] = 0; // Simular que no está deshabilitado
            }
            return true;
        } else if (stripos($this->query, 'SELECT dia_semana FROM profesionales_dias_deshabilitados') !== false) {
            // No tenemos días deshabilitados en nuestro mock
            return false;
        }
        return false;
    }
    
    public function execute() {
        // Simulación simple para SELECTs
        if (stripos($this->query, 'SELECT') !== false) {
            // Retornar datos vacíos para todas las consultas de turnos por simplicidad
            $this->lastResult = [];
            if (stripos($this->query, 'SELECT deshabilitado FROM profesionales_deshabilitados') !== false) {
                $this->lastResult = [['deshabilitado' => 0]]; // No deshabilitado
            }
            return true;
        }
        return true; // Para todas las demás consultas, pretender éxito
    }
    
    public function get_result() {
        return new MockResult($this->lastResult);
    }
}

class MockResult {
    private $data;
    private $position = 0;
    
    public function __construct($data) {
        $this->data = $data;
    }
    
    public function fetch_assoc() {
        if ($this->position >= count($this->data)) {
            return null;
        }
        
        return $this->data[$this->position++];
    }
    
    public function __get($name) {
        if ($name === 'num_rows') {
            return count($this->data);
        }
        
        return null;
    }
}

// Crear una base de datos simulada para pruebas
$mysqli = new MockDatabase();

// Variable para almacenar los horarios disponibles desde la sesión
$disponibilidadProfesionales = isset($_SESSION['disponibilidadProfesionales']) ? $_SESSION['disponibilidadProfesionales'] : [];

// Si no hay disponibilidad en la sesión, definir los horarios disponibles por defecto
if (empty($disponibilidadProfesionales)) {
    // Definir los horarios disponibles para todos los profesionales (Siempre los definimos)
    $disponibilidadProfesionales = [
        'Lucia Foricher' => [
            'Monday' => ['08:00', '09:00', '10:00', '11:00'],
            'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
            'Friday' => ['08:00', '09:00', '10:00', '11:00']
        ],
        'Mauro Robert' => [
            'Monday' => ['13:00', '14:00', '15:00', '16:00'],
            'Tuesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Thursday' => ['13:00', '14:00', '15:00', '16:00'],
            'Friday' => ['13:00', '14:00', '15:00', '16:00']
        ],
        'German Fernandez' => [
            'Monday' => ['17:30', '18:30', '19:30'],
            'Tuesday' => ['17:30', '18:30', '19:30'],
            'Wednesday' => ['17:30', '18:30', '19:30'],
            'Thursday' => ['17:30', '18:30', '19:30'],
            'Friday' => ['17:30', '18:30', '19:30']
        ],
        'Gastón Olgiati' => [
            'Monday' => ['13:00', '14:00', '15:00', '16:00'],
            'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Friday' => ['13:00', '14:00', '15:00', '16:00']
        ],
        'Hernan Lopez' => [
            'Tuesday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
            'Thursday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
        ],
        'Alejandro Perez' => [
            'Monday' => ['08:00', '09:00', '10:00', '11:00'],
            'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
            'Friday' => ['08:00', '09:00', '10:00', '11:00']
        ],
        'Melina Thome' => [
            'Monday' => ['17:00', '18:00', '19:00'],
            'Wednesday' => ['17:00', '18:00', '19:00'],
            'Friday' => ['17:00', '18:00', '19:00']
        ],
        'Maria Paz' => [
            'Wednesday' => ['17:00', '18:00', '19:00'],
            'Saturday' => ['12:00']
        ],
        'Miriam Rossello' => [
            'Tuesday' => [
                '08:00', '08:15', '08:30', '08:45',
                '09:00', '09:15', '09:30', '09:45',
                '10:00', '10:15', '10:30', '10:45',
                '11:00', '11:15', '11:30', '11:45'
            ],
            'Thursday' => [
                '08:00', '08:15', '08:30', '08:45',
                '09:00', '09:15', '09:30', '09:45',
                '10:00', '10:15', '10:30', '10:45',
                '11:00', '11:15', '11:30', '11:45'
            ]
        ],
        'Florencia Goñi' => [
            'Monday' => ['17:00', '18:00'],
            'Tuesday' => ['17:00', '18:00'],
            'Thursday' => ['17:00']
        ],
        'Constanza Marinello' => [
            'Monday' => ['15:00'],
            'Tuesday' => ['16:00', '17:00'],
            'Thursday' => ['13:00', '14:00', '15:00'],
            'Friday' => ['15:00', '16:00']
        ],
        'Mariana Ilari' => [
            'Monday' => ['08:30', '09:30', '10:30', '11:30'],
            'Wednesday' => ['10:30', '11:30'],
            'Thursday' => ['08:30', '09:30', '10:30', '11:30'],
            'Friday' => ['17:00', '18:00']
        ],
        'Leila Heguilein' => [
            'Tuesday' => ['17:00', '18:00', '19:00', '20:00'],
            'Wednesday' => ['17:00', '18:00', '19:00', '20:00'],
        ],
        'Lucia Foricher (Terapia Manual - RPG)' => [
            'Monday' => ['16:00', '17:00', '18:00', '19:00'],
            'Wednesday' => ['16:00', '17:00', '18:00', '19:00'],
            'Tuesday' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
            'Thursday' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
            'Friday' => ['12:00', '13:00', '14:00', '15:00']
        ],
        'Mariana Ilari (Terapia Manual - RPG)' => [
            'Monday' => ['08:30', '09:30', '10:30', '11:30'],
            'Wednesday' => ['10:30', '11:30'],
            'Thursday' => ['08:30', '09:30', '10:30', '11:30'],
            'Friday' => ['17:00', '18:00']
        ]
    ];
}

// Guardar en sesión para otros scripts
$_SESSION['disponibilidadProfesionales'] = $disponibilidadProfesionales;

$servicio = isset($_SESSION['servicio']) ? $_SESSION['servicio'] : 'Kinesiología';

// Si no se ha seleccionado un profesional, redirigir a profesionales.php
if (!isset($_SESSION['profesional'])) {
    header('Location: profesionales.php');
    exit();
}

// Nombre del profesional
$profesional = $_SESSION['profesional'];

// Verificar si el profesional está deshabilitado completamente usando la tabla original
$profesional_deshabilitado = false;
$query = $mysqli->prepare("SELECT deshabilitado FROM profesionales_deshabilitados WHERE profesional = ?");
$query->bind_param("s", $profesional);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $profesional_deshabilitado = (bool)$row['deshabilitado'];
    
    if ($profesional_deshabilitado) {
        die("El profesional $profesional no está disponible actualmente.");
    }
}

// Obtener los días específicos deshabilitados para este profesional
$dias_deshabilitados = [];
$query = $mysqli->prepare("SELECT dia_semana FROM profesionales_dias_deshabilitados WHERE profesional = ? AND deshabilitado = 1");
$query->bind_param("s", $profesional);
$query->execute();
$result = $query->get_result();
while ($row = $result->fetch_assoc()) {
    $dias_deshabilitados[] = $row['dia_semana'];
}

// Si el formulario es enviado, guardar fecha y hora en variables de sesión y redirigir a paciente.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];

    // Guardar fecha y hora en la sesión
    $_SESSION['fecha'] = $fecha;
    $_SESSION['hora'] = $hora;

    // Redirigir a paciente.php
    header('Location: paciente.php');
    exit();
}

// Obtener las horas ocupadas para el profesional en una fecha específica (vía AJAX)
if (isset($_GET['fecha'])) {
    $fecha = $_GET['fecha'];
    $diaSemana = date('l', strtotime($fecha)); // Obtener el día de la semana de la fecha seleccionada
    
    // Verificar si el profesional está deshabilitado
    $query = $mysqli->prepare("SELECT deshabilitado FROM profesionales_deshabilitados WHERE profesional = ?");
    $query->bind_param("s", $profesional);
    $query->execute();
    $result = $query->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ((bool)$row['deshabilitado']) {
            echo json_encode([]);
            exit();
        }
    }
    
    // Verificar si el día específico está deshabilitado para este profesional
    if (in_array($diaSemana, $dias_deshabilitados)) {
        echo json_encode([]);
        exit();
    }
    
    // Verificar si el día de la semana tiene disponibilidad definida
    $horasDisponibles = [];
    
    if ($servicio == 'Terapia Manual - RPG') {
        // Clave para profesional con servicio de Terapia Manual
        $profesionalTerapiaManual = $profesional . ' (Terapia Manual - RPG)';
        
        // Buscar en la estructura específica para Terapia Manual - RPG 
        if (isset($disponibilidadProfesionales[$profesionalTerapiaManual][$diaSemana])) {
            $horasDisponibles = $disponibilidadProfesionales[$profesionalTerapiaManual][$diaSemana];
        } else {
            // Buscar en la estructura alternativa (días con formato específico)
            $diaConTerapia = $diaSemana . ' (Terapia Manual - RPG)';
            if (isset($disponibilidadProfesionales[$profesional][$diaConTerapia])) {
                $horasDisponibles = $disponibilidadProfesionales[$profesional][$diaConTerapia];
            }
        }
    } elseif (isset($disponibilidadProfesionales[$profesional][$diaSemana])) {
        $horasDisponibles = $disponibilidadProfesionales[$profesional][$diaSemana];
    }
    
    // Si no hay horas disponibles, devolver array vacío
    if (empty($horasDisponibles)) {
        echo json_encode([]);
        exit();
    }

    // Para kinesiología, solo consideramos un horario ocupado cuando hay 4 pacientes
    // Para otros servicios, con 1 paciente ya se considera ocupado
    $horasOcupadas = [];
    
    if ($servicio == 'Kinesiología') {
        // Para kinesiología, contar el número de pacientes por hora
        $stmt = $mysqli->prepare("SELECT TIME_FORMAT(hora, '%H:%i') as hora, COUNT(*) as num_pacientes 
                                 FROM turnos 
                                 WHERE profesional = ? AND fecha = ? AND servicio = 'Kinesiología'
                                 GROUP BY hora 
                                 HAVING num_pacientes >= 4");
        $stmt->bind_param("ss", $profesional, $fecha);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            // Solo agregar horarios que tengan 4 o más pacientes
            $horasOcupadas[] = $row['hora'];
        }
    } else {
        // Para otros servicios, un horario se considera ocupado con 1 solo paciente
        $stmt = $mysqli->prepare("SELECT TIME_FORMAT(hora, '%H:%i') as hora 
                                 FROM turnos 
                                 WHERE profesional = ? AND fecha = ? AND servicio = ?");
        $stmt->bind_param("sss", $profesional, $fecha, $servicio);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            $horasOcupadas[] = $row['hora'];
        }
    }

    // Filtrar horarios disponibles
    $horasFinales = array_values(array_diff($horasDisponibles, $horasOcupadas));
    
    echo json_encode($horasFinales);
    exit();
}

$imagenes_profesionales = [
    'Florencia Goñi' => 'img/florencia.jpg',
    'Constanza Marinello' => 'img/constanza.jpg',     
    'Maria Paz' => 'img/maria.jpg',
    'Lucia Foricher' => 'img/lucia.jpg',
    'Mariana Ilari' => 'img/mariana.jpg',
    'Miriam Rossello' => 'img/miriam.jpg',
    'Mauro Robert' => 'img/mauro.jpg',
    'German Fernandez' => 'img/german.jpg',
    'Gastón Olgiati' => 'img/gastonO.jpg',
    'Melina Thome' => 'img/melina.jpg',
    'Hernan Lopez' => 'img/hernan.jpg',
    'Alejandro Perez' => 'img/alejandro.jpg',
    'Leila Heguilein' => 'img/leila.jpg',
];

$profesionalesDescripciones = [
    'Hernan Lopez' => [
        'nombre' => 'Hernan Lopez',
        'imagen' => '../img/hernan.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Área de abordaje: traumatología y neurorehabilitación en adultos mayores.'
        ]
    ],
    'Miriam Rossello' => [
        'nombre' => 'Miriam Rossello',
        'imagen' => '../img/miriam.jpg',
        'descripciones' => [
            'Especialista en miembro superior'
        ]
    ],
    'Maria Paz' => [
        'nombre' => 'Maria Paz',
        'imagen' => '../img/maria.jpg',
        'descripciones' => [
            'Lic. Nutrición',
            'Área de abordaje: traumatología y neurorehabilitación en adultos mayores.'
        ]
    ],
    'Alejandro Perez' => [
        'nombre' => 'Alejandro Perez Etcheber',
        'imagen' => '../img/alejandro.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Curso de abordaje integral del adulto mayor',
            'Curso de kinefilaxia, flexibilidad y movilidad.'
        ]
    ],
    'Melina Thome' => [
        'nombre' => 'Melina Thome',
        'imagen' => '../img/melina.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Área de abordaje: rehabilitación traumatológica de adultos y adultos mayores.'
        ]
    ],
    'Leila Heguilein' => [
        'nombre' => 'Leila Heguilein',
        'imagen' => '../img/leila.jpg',
        'descripciones' => [
            'Licenciada en psicología',
            'Formacion en profesorado en psicología ',
            'Actualmente trabajando en el dispositivo de hospital de día y en el dispositivo de adicciones de la clínica privada bahiense'
        ]
    ],
    'Mauro Robert' => [
        'nombre' => 'Dr. Mauro Robert',
        'imagen' => '../img/mauro.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Rehabilitación traumatológica deportiva',
            'Método Busquet en formación',
            'MEP sports',
            'Tapping neuromuscular',
            'Punción seca'
        ]
    ],
    'Gastón Olgiati' => [
        'nombre' => 'Gastón Olgiati',
        'imagen' => 'img/GastonO.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Método Busquet en formación',
            'Tapping neuromuscular',
            'MEP Sports',
            'Vendaje deportivo',
            'Reprogramación propioceptiva'
        ]
    ],
    'German Fernandez' => [
        'nombre' => 'Dr. German Fernandez',
        'imagen' => '../img/german.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Orientación: rehabilitación traumatológica y deportiva, atención de adultos mayores',
            'Cursos:',
            'Abordaje integral del adulto mayor - AAK',
            'Gimnasia postural',
            'Reprogramación propioceptiva Busquet',
            'Actualización en tendinopatías'
        ]
    ],
    'Mariana Ilari' => [
        'nombre' => 'Mariana Ilari',
        'imagen' => '../img/mariana.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Método Busquet, reprogramación propioceptiva',
            'Rehabilitación traumatológica y postural',
            'Concepto Mulligan',
            'TMR'
        ]
    ],
    'Lucia Foricher' => [
        'nombre' => 'Lucia Foricher Castellon',
        'imagen' => '../img/lucia.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP (2018)',
            'Formada en:',
            'TMR-Técnicas Metaméricas Reflejas, formación completa',
            'Método Busquet, formación completa y reprogramación propioceptiva',
            'Métodos globales de corrección postural',
            'Mulligan Concept',
            'Punción seca',
            'Drenaje linfático manual, método Leduc'
        ]
    ],
    'Constanza Marinello' => [
        'nombre' => 'Constanza Marinello',
        'imagen' => '../img/constanza.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Posgrado en kinesiología dermatofuncional y estética',
            'Curso superior de Flebología y Linfología, Método Leduc'
        ]
    ],
    'Florencia Goñi' => [
        'nombre' => 'Florencia Goñi',
        'imagen' => '../img/florencia.jpg',
        'descripciones' => [
            'Lic. en kinesiología y fisiatría, UCALP',
            'Posgrado en kinesiología dermatofuncional y estética',
            'Curso superior de Flebología y Linfología, Método Leduc'
        ]
    ]
];

$descripcionCorta = isset($profesionalesDescripciones[$profesional]['descripciones'][0]) ? $profesionalesDescripciones[$profesional]['descripciones'][0] : 'Descripción no disponible';

// Crear un array de los días de la semana en que el profesional NO tiene disponibilidad para el servicio solicitado
$diasSinDisponibilidad = [];
$diasSemana = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
if ($profesional !== 'Maria Paz') {
    $diasSemana[] = 'Saturday';
    $diasSemana[] = 'Sunday';
}

// Agregar los días específicos deshabilitados por el profesional
$diasSinDisponibilidad = array_merge($diasSinDisponibilidad, $dias_deshabilitados);

if ($servicio == 'Terapia Manual - RPG') {
    $profesionalTerapiaManual = $profesional . ' (Terapia Manual - RPG)';
    foreach ($diasSemana as $dia) {
        $tieneDiaEspecifico = isset($disponibilidadProfesionales[$profesionalTerapiaManual][$dia]) && 
                             !empty($disponibilidadProfesionales[$profesionalTerapiaManual][$dia]);
        
        $tieneDiaConTerapia = isset($disponibilidadProfesionales[$profesional][$dia . ' (Terapia Manual - RPG)']) && 
                             !empty($disponibilidadProfesionales[$profesional][$dia . ' (Terapia Manual - RPG)']);
        
        if (!$tieneDiaEspecifico && !$tieneDiaConTerapia) {
            $diasSinDisponibilidad[] = $dia;
        }
    }
} else {
    foreach ($diasSemana as $dia) {
        if (!isset($disponibilidadProfesionales[$profesional][$dia]) || 
            empty($disponibilidadProfesionales[$profesional][$dia])) {
            $diasSinDisponibilidad[] = $dia;
        }
    }
}

// Eliminar duplicados de $diasSinDisponibilidad
$diasSinDisponibilidad = array_unique($diasSinDisponibilidad);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sante - Horario</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.css">
    <script src="bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300&family=Noto+Sans&family=Poppins:wght@300&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/989f8affb2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
    <link rel="icon" href="img/santeLogo.jpg">

    <style>
        body{
            background-color: rgb(246, 241, 238) !important;
        }

        .calendar-container {
            width: 100%;
            margin: auto;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            top: 20px;
        }

        .flatpickr-calendar {
            font-size: 16px;
            padding: 10px;
        }
        .time-card {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .time-slot {
            display: inline-block;
            margin: 5px;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            background-color: #f1f1f1;
        }
        .time-slot.disabled {
            background-color: #e0e0e0;
            cursor: not-allowed;
        }
        .time-slot.available:hover {
            background-color: #9DBC98;
            color: white;
        }
        #modal-content {
            background-color: #fff;
            color: #333;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }
        #confirmarTurno {
            display: none;
            background-color: #9DBC98;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            position: relative;
            top: 10px;
            margin: auto;
        }
        #closeModal {
            background-color: red;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            border: none;
        }
        button:hover {
            background-color: #45a049;
        }
        .flatpickr-clear {
            display: none;
        }
        .servicio_title {
            text-align: center;
            margin: auto;
            letter-spacing: 9px;
            font-weight: 700;
            position: relative;
            top: 30px;
            background-color: #fff;
            max-width: 600px ;
            padding: 10px;
            border: 2px solid #9DBC98;
            border-radius: 50px;
        }

        .profesionalesIMG{
            width: 200px;
            height: 85vh;
            background-color: rgba(99, 136, 137, 1);
            position: absolute;
            top: 10;
            left: 0 ;
            border-radius: 16px;
        }

        .profesional_img {
            width: 200px;
            height: 300px;
            border-radius: 0%;
            overflow: hidden;
            margin-bottom: 10px;
            margin: auto;
            position: relative;
            top: 40px;
            padding: 10px;
        }

        .profesional_img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profesional-info h2 {
            font-size: 25px;
            text-align: center;
            margin-top: 5px;
            color: white;
            position: relative;
            top: 50px;
            font-weight: 600;
        }

        .profesional-info p {
            font-size: 17px;
            text-align: center;
            margin-top: 5px;
            color: rgb(190, 190, 190);
            position: relative;
            top: 50px;
        }

        .btn-vermas {
            z-index: 300;
            position: relative;
            top: 50px;
            margin: 0 auto;
            text-align: center;
            background-color: #9DBC98;
            height: 40px;
            width: 100px;
            padding: 10px;
            text-decoration: none;
            color: #fff;
            position: absolute;
            top: 90%;
            left: 23%;
            border-radius: 10px;
        }

        .btn-vermas:hover {
            color: #fff;
            background-color: rgb(131, 165, 126);
            transition: 0.5s;
        }

        .fecha{
            max-width: 10px;
        }

        @media (max-width: 768px) {
            .calendar-container {
                width: 100%;
                padding: 10px;
            }
            

            .logo_container{
                width: 90%;
                display: flex;
                justify-content: start;
            }

            

            .profesionalesIMG {
                width: 90%;
                height: 300px;
                margin-bottom: 380px;
                position: relative;
            }

            .profesional_img {
                height: 100px;
                width: 100px;
                margin: auto;
                margin-top: 20px;
                margin-left: 16px;
                position: absolute;
                top: 0;
                left: 0;
            }

            .profesional-info h2 {
                text-align: center;
                position: absolute;
                width: 75%;
                top: 40px;
                left: 120px;
                font-size: 1.3rem;
            }

            .profesional-info p {
                text-align: center;
                position: absolute;
                top: 120px;
                font-size: 1rem;
                width: 90%;
                left: 5%;
            }

            .btn-vermas {
                margin: auto;
                text-align: center;
                background-color: #9DBC98;
                padding: 10px;
                text-decoration: none;
                color: #fff;
                position: absolute;
                top: 180px;
                left: 40%;
                border-radius: 10px;
            }

            .servicio_title {
                font-size: 14px;
                padding: 10px;
                margin-top: 330px;
                letter-spacing: 6px;
                max-width: 90%;
            }

            .calendario {
                width: 100%;
                padding: 10px;
                margin-top: 100px;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav class="nav_container navbar navbar-dark navbar-expand-lg">
            <div class="container-fluid">
                <div class="logo_container">
                    <img class="logo animate__animated animate__fadeInDown" src="img/santeLogo.jpg" alt="Logo">
                </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" 
                        aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <ul class="ul_container navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav_link nav-link" href="servicios.php">Volver</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <aside class="profesionalesIMG">
        <div class="profesional_img animate__animated animate__fadeInLeft">
            <?php if (isset($imagenes_profesionales[$profesional])): ?>
                <img src="<?php echo $imagenes_profesionales[$profesional]; ?>" alt="<?php echo $profesional; ?>">
            <?php else: ?>
                <img src="img/placeholder.jpg" alt="Imagen no disponible">
            <?php endif; ?>
        </div>
        <div class="profesional-info">
            <h2 class="animate__animated animate__fadeInLeft"><?php echo $profesional; ?></h2>
            <p class="animate__animated animate__fadeInLeft"><?php echo $descripcionCorta; ?></p>
        </div>
        <?php if (isset($profesionalesDescripciones[$profesional])): ?>
            <a href="profesional.php?nombre=<?php echo $profesional; ?>" class="btn-vermas animate__animated animate__fadeInLeft">Ver más</a>
        <?php endif; ?>
    </aside>

    <h2 class="servicio_title animate__animated animate__fadeInDown">
        <?php echo htmlspecialchars($servicio); ?>
    </h2>

    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center calendario">
                <div class="calendar-container animate__animated animate__fadeInUp">
                    <div id="calendar"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="time-card">
        <div id="modal-content">
            <h4>Seleccione un horario</h4>
            <div id="time-slots"></div>
            <br>
            <button id="closeModal">Cerrar</button>
            <form id="turnoForm" method="post">
                <input type="hidden" id="fecha" name="fecha">
                <input type="hidden" id="hora" name="hora">
                <button type="submit" id="confirmarTurno">Confirmar Turno</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://npmcdn.com/flatpickr/dist/l10n/es.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Configurar los días sin disponibilidad
            var diasSinDisponibilidad = <?php echo json_encode($diasSinDisponibilidad); ?>;
            
            // Flatpickr options
            var options = {
                inline: true,
                minDate: "today",
                maxDate: new Date().fp_incr(60), // 60 días desde hoy
                locale: "es",
                dateFormat: "Y-m-d",
                
                disable: [
                    function(date) {
                        // Obtener el nombre del día en inglés
                        const diaName = date.toLocaleDateString('en-US', { weekday: 'long' });
                        
                        // Comprobar si es un día sin disponibilidad para este profesional y servicio
                        if (diasSinDisponibilidad.includes(diaName)) {
                            return true; // Deshabilitar este día
                        }
                        
                        // Deshabilitar sábados y domingos, excepto para 'Maria Paz'
                        return (diaName === 'Saturday' || diaName === 'Sunday') && 
                                '<?php echo $profesional; ?>' !== 'Maria Paz';
                    }
                ],
                onChange: function(selectedDates, dateStr) {
                    // Cuando se selecciona una fecha, mostrar el modal de horarios
                    getAvailableHours(dateStr);
                }
            };

            var calendarEl = document.getElementById('calendar');
            var calendarInstance = flatpickr(calendarEl, options);

            var timeCard = document.querySelector('.time-card');
            var timeSlots = document.getElementById('time-slots');
            var closeModal = document.getElementById('closeModal');
            var confirmarTurno = document.getElementById('confirmarTurno');
            var selectedTimeSlot = null;

            closeModal.addEventListener('click', function() {
                timeCard.style.display = 'none';
                selectedTimeSlot = null;
                confirmarTurno.style.display = 'none';
            });

            function getAvailableHours(date) {
                // Solicitud AJAX para obtener horas disponibles
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'fecha.php?fecha=' + date, true);
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        try {
                            var availableHours = JSON.parse(xhr.responseText);
                            showTimeSlots(availableHours, date);
                        } catch (e) {
                            console.error('Error parsing response:', e);
                            showTimeSlots([], date);
                        }
                    } else {
                        console.error('Request failed. Status:', xhr.status);
                        showTimeSlots([], date);
                    }
                };
                xhr.onerror = function() {
                    console.error('Request failed');
                    showTimeSlots([], date);
                };
                xhr.send();
            }

            function showTimeSlots(availableHours, date) {
                // Ordenar horas disponibles
                availableHours.sort();
                
                // Mostrar el modal y llenar con horas disponibles
                timeCard.style.display = 'flex';
                timeSlots.innerHTML = '';
                
                if (availableHours.length === 0) {
                    timeSlots.innerHTML = '<p>No hay horarios disponibles para esta fecha.</p>';
                    return;
                }
                
                availableHours.forEach(function(hour) {
                    var timeSlot = document.createElement('div');
                    timeSlot.className = 'time-slot available';
                    timeSlot.textContent = hour;
                    timeSlot.dataset.hour = hour;
                    
                    timeSlot.addEventListener('click', function() {
                        // Resetear selección anterior
                        document.querySelectorAll('.time-slot').forEach(function(slot) {
                            slot.classList.remove('selected');
                            slot.style.backgroundColor = '';
                            slot.style.color = '';
                        });
                        
                        // Marcar como seleccionado
                        this.classList.add('selected');
                        this.style.backgroundColor = '#9DBC98';
                        this.style.color = 'white';
                        
                        // Guardar hora seleccionada
                        selectedTimeSlot = hour;
                        document.getElementById('fecha').value = date;
                        document.getElementById('hora').value = hour;
                        
                        // Mostrar botón confirmar
                        confirmarTurno.style.display = 'block';
                    });
                    
                    timeSlots.appendChild(timeSlot);
                });
            }
        });
    </script>
</body>
</html>