<?php
// Database configuration file
$mysqli = new mysqli("localhost", "u843239035_lauolgiati", "Santekinesio1", "u843239035_sante");

if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}

// Function to get professional schedules from database
function getDisponibilidadProfesionales() {
    global $mysqli;
    
    // Check if the table exists, if not, create it
    $mysqli->query("CREATE TABLE IF NOT EXISTS profesionales_horarios (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        profesional VARCHAR(255) NOT NULL,
        dia VARCHAR(50) NOT NULL,
        hora VARCHAR(10) NOT NULL,
        servicio VARCHAR(50) DEFAULT 'Kinesiología',
        UNIQUE KEY unique_horario (profesional, dia, hora, servicio)
    )");
    
    // Get all schedules from database
    $result = $mysqli->query("SELECT profesional, dia, hora, servicio FROM profesionales_horarios ORDER BY profesional, dia, hora");
    
    $disponibilidad = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $profesional = $row['profesional'];
            $dia = $row['dia'];
            $hora = $row['hora'];
            $servicio = $row['servicio'];
            
            // For Terapia Manual, store with service indicator
            if ($servicio === 'Terapia Manual - RPG') {
                if (!isset($disponibilidad[$profesional . ' (Terapia Manual - RPG)'][$dia])) {
                    $disponibilidad[$profesional . ' (Terapia Manual - RPG)'][$dia] = [];
                }
                $disponibilidad[$profesional . ' (Terapia Manual - RPG)'][$dia][] = $hora;
                
                // Also store in regular schedule with day indicator
                $diaTerapia = $dia . ' (Terapia Manual - RPG)';
                if (!isset($disponibilidad[$profesional][$diaTerapia])) {
                    $disponibilidad[$profesional][$diaTerapia] = [];
                }
                $disponibilidad[$profesional][$diaTerapia][] = $hora;
            } else {
                if (!isset($disponibilidad[$profesional][$dia])) {
                    $disponibilidad[$profesional][$dia] = [];
                }
                $disponibilidad[$profesional][$dia][] = $hora;
            }
        }
    }
    
    // If no schedules found, we'll initialize with defaults
    if (empty($disponibilidad)) {
        // Default schedules to be inserted into the database
        $defaultSchedules = [
            'Lucia Foricher' => [
                'Monday' => ['08:00', '09:00', '10:00', '11:00'],
                'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
                'Friday' => ['08:00', '09:00', '10:00', '11:00']
            ],
            'Mauro Robert' => [
                'Monday' => ['13:00', '14:00', '15:00', '16:00'],
                'Tuesday' => ['13:00', '14:00', '15:00', '16:00'],
                'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
                'Thursday' => ['13:00', '14:00', '15:00', '16:00'],
                'Friday' => ['13:00', '14:00', '15:00', '16:00']
            ],
            'German Fernandez' => [
                'Monday' => ['17:30', '18:30', '19:30'],
                'Tuesday' => ['17:30', '18:30', '19:30'],
                'Wednesday' => ['17:30', '18:30', '19:30'],
                'Thursday' => ['17:30', '18:30', '19:30'],
                'Friday' => ['17:30', '18:30', '19:30']
            ],
            'Gastón Olgiati' => [
                'Monday' => ['13:00', '14:00', '15:00', '16:00'],
                'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
                'Friday' => ['13:00', '14:00', '15:00', '16:00']
            ],
            'Hernan Lopez' => [
                'Tuesday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
                'Thursday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
            ],
            'Alejandro Perez' => [
                'Monday' => ['08:00', '09:00', '10:00', '11:00'],
                'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
                'Friday' => ['08:00', '09:00', '10:00', '11:00']
            ],
            'Melina Thome' => [
                'Monday' => ['17:00', '18:00', '19:00'],
                'Wednesday' => ['17:00', '18:00', '19:00'],
                'Friday' => ['17:00', '18:00', '19:00']
            ],
            'Maria Paz' => [
                'Wednesday' => ['17:00', '18:00', '19:00'],
                'Saturday' => ['12:00']
            ],
            'Miriam Rossello' => [
                'Tuesday' => [
                    '08:00', '08:15', '08:30', '08:45',
                    '09:00', '09:15', '09:30', '09:45',
                    '10:00', '10:15', '10:30', '10:45',
                    '11:00', '11:15', '11:30', '11:45'
                ],
                'Thursday' => [
                    '08:00', '08:15', '08:30', '08:45',
                    '09:00', '09:15', '09:30', '09:45',
                    '10:00', '10:15', '10:30', '10:45',
                    '11:00', '11:15', '11:30', '11:45'
                ]
            ],
            'Florencia Goñi' => [
                'Monday' => ['17:00', '18:00'],
                'Tuesday' => ['17:00', '18:00'],
                'Thursday' => ['17:00']
            ],
            'Constanza Marinello' => [
                'Monday' => ['15:00'],
                'Tuesday' => ['16:00', '17:00'],
                'Thursday' => ['13:00', '14:00', '15:00'],
                'Friday' => ['15:00', '16:00']
            ],
            'Mariana Ilari' => [
                'Monday' => ['08:30', '09:30', '10:30', '11:30'],
                'Wednesday' => ['10:30', '11:30'],
                'Thursday' => ['08:30', '09:30', '10:30', '11:30'],
                'Friday' => ['17:00', '18:00']
            ],
            'Leila Heguilein' => [
                'Tuesday' => ['17:00', '18:00', '19:00', '20:00'],
                'Wednesday' => ['17:00', '18:00', '19:00', '20:00'],
            ]
        ];
        
        // Terapia Manual - RPG schedules
        $terapiaManualSchedules = [
            'Lucia Foricher' => [
                'Monday' => ['16:00', '17:00', '18:00', '19:00'],
                'Wednesday' => ['16:00', '17:00', '18:00', '19:00'],
                'Tuesday' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
                'Thursday' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
                'Friday' => ['12:00', '13:00', '14:00', '15:00']
            ],
            'Mariana Ilari' => [
                'Monday' => ['08:30', '09:30', '10:30', '11:30'],
                'Wednesday' => ['10:30', '11:30'],
                'Thursday' => ['08:30', '09:30', '10:30', '11:30'],
                'Friday' => ['17:00', '18:00']
            ]
        ];
        
        // Insert regular schedules
        $stmt = $mysqli->prepare("INSERT INTO profesionales_horarios (profesional, dia, hora, servicio) VALUES (?, ?, ?, 'Kinesiología')");
        $stmt->bind_param("sss", $profesional, $dia, $hora);
        
        foreach ($defaultSchedules as $profesional => $dias) {
            foreach ($dias as $dia => $horas) {
                foreach ($horas as $hora) {
                    $stmt->execute();
                }
            }
        }
        
        // Insert Terapia Manual schedules
        $stmt = $mysqli->prepare("INSERT INTO profesionales_horarios (profesional, dia, hora, servicio) VALUES (?, ?, ?, 'Terapia Manual - RPG')");
        
        foreach ($terapiaManualSchedules as $profesional => $dias) {
            foreach ($dias as $dia => $horas) {
                foreach ($horas as $hora) {
                    $stmt->execute();
                }
            }
        }
        
        // Fetch the newly inserted schedules
        return getDisponibilidadProfesionales();
    }
    
    return $disponibilidad;
}

// Function to update professional schedule
function updateProfesionalHorarios($profesional, $nuevosHorarios, $servicio = 'Kinesiología') {
    global $mysqli;
    
    // Begin transaction
    $mysqli->begin_transaction();
    
    try {
        // Delete existing schedules for this professional and service
        $stmt = $mysqli->prepare("DELETE FROM profesionales_horarios WHERE profesional = ? AND servicio = ?");
        $stmt->bind_param("ss", $profesional, $servicio);
        $stmt->execute();
        
        // Insert new schedules
        $stmt = $mysqli->prepare("INSERT INTO profesionales_horarios (profesional, dia, hora, servicio) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $profesional, $dia, $hora, $servicio);
        
        foreach ($nuevosHorarios as $dia => $horas) {
            // Skip special day format for Terapia Manual when inserting in Kinesiología
            if ($servicio === 'Kinesiología' && strpos($dia, '(Terapia Manual - RPG)') !== false) {
                continue;
            }
            
            // For Terapia Manual, remove the suffix from day names
            $diaParaInsertar = $dia;
            if ($servicio === 'Terapia Manual - RPG') {
                $diaParaInsertar = str_replace(' (Terapia Manual - RPG)', '', $dia);
            }
            
            $dia = $diaParaInsertar;
            foreach ($horas as $hora) {
                $stmt->execute();
            }
        }
        
        // Commit transaction
        $mysqli->commit();
        return true;
    } catch (Exception $e) {
        // Rollback in case of error
        $mysqli->rollback();
        error_log("Error actualizando horarios: " . $e->getMessage());
        return false;
    }
}
?>
