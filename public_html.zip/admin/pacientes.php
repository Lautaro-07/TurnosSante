<?php
session_start([
    'cookie_lifetime' => 0, // La sesión se cierra cuando se cierra el navegador
]);
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}
$profesional = $_SESSION['profesional'];
// Horarios disponibles por profesional en Sante
if (!isset($_SESSION['disponibilidadProfesionales'])) {
    $_SESSION['disponibilidadProfesionales'] = [
        'Lucia Foricher' => [
            'Monday' => ['08:00', '09:00', '10:00', '11:00'],
            'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
            'Friday' => ['08:00', '09:00', '10:00', '11:00'],
            'Monday (Terapia Manual - RPG)' => ['16:00', '17:00', '18:00', '19:00'],
            'Wednesday (Terapia Manual - RPG)' => ['16:00', '17:00', '18:00', '19:00'],
            'Tuesday (Terapia Manual - RPG)' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
            'Thursday (Terapia Manual - RPG)' => ['11:00', '12:00', '13:00', '14:00', '15:00'],
            'Friday (Terapia Manual - RPG)' => ['12:00', '13:00', '14:00', '15:00']
        ],
        'Mauro Robert' => [
            'Monday' => ['13:00', '14:00', '15:00', '16:00'],
            'Tuesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Thursday' => ['13:00', '14:00', '15:00', '16:00'],
            'Friday' => ['13:00', '14:00', '15:00', '16:00']
        ],
        'German Fernandez' => [
            'Monday' => ['17:30', '18:30', '19:30'],
            'Tuesday' => ['17:30', '18:30', '19:30'],
            'Wednesday' => ['17:30', '18:30', '19:30'],
            'Thursday' => ['17:30', '18:30', '19:30'],
            'Friday' => ['17:30', '18:30', '19:30']
        ],
        'Gastón Olgiati' => [
            'Monday' => ['13:00', '14:00', '15:00', '16:00'],
            'Wednesday' => ['13:00', '14:00', '15:00', '16:00'],
            'Friday' => ['13:00', '14:00', '15:00', '16:00']
        ],
        'Hernan Lopez' => [
            'Tuesday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
            'Thursday' => ['08:00', '09:00', '10:00', '11:00', '12:00'],
        ],
        'Alejandro Perez' => [
            'Monday' => ['08:00', '09:00', '10:00', '11:00'],
            'Wednesday' => ['08:00', '09:00', '10:00', '11:00'],
            'Friday' => ['08:00', '09:00', '10:00', '11:00']
        ],
        'Melina Thome' => [
            'Monday' => ['17:00', '18:00', '19:00'],
            'Wednesday' => ['17:00', '18:00', '19:00'],
            'Friday' => ['17:00', '18:00', '19:00']
        ],
        'Maria Paz' => [
            'Wednesday' => ['17:00', '18:00', '19:00'],
            'Saturday' => ['12:00']
        ],
        'Miriam Rossello' => [
            'Tuesday' => [
                '08:00', '08:15', '08:30', '08:45',
                '09:00', '09:15', '09:30', '09:45',
                '10:00', '10:15', '10:30', '10:45',
                '11:00', '11:15', '11:30', '11:45'
            ],
            'Thursday' => [
                '08:00', '08:15', '08:30', '08:45',
                '09:00', '09:15', '09:30', '09:45',
                '10:00', '10:15', '10:30', '10:45',
                '11:00', '11:15', '11:30', '11:45'
            ]
        ],
        'Florencia Goñi' => [
            'Monday' => ['17:00', '18:00'],
            'Tuesday' => ['17:00', '18:00'],
            'Thursday' => ['17:00']
        ],
        'Constanza Marinello' => [
            'Monday' => ['15:00'],
            'Tuesday' => ['16:00', '17:00'],
            'Thursday' => ['13:00', '14:00', '15:00'],
            'Friday' => ['15:00', '16:00']
        ],
        'Mariana Ilari' => [
            'Monday' => ['08:30', '09:30', '10:30', '11:30'],
            'Wednesday' => ['10:30', '11:30'],
            'Thursday' => ['08:30', '09:30', '10:30', '11:30'],
            'Friday' => ['17:00', '18:00']
        ],
        'Leila Heguilein' => [
            'Tuesday' => ['17:00', '18:00', '19:00', '20:00'],
            'Wednesday' => ['17:00', '18:00', '19:00', '20:00'],
        ]
    ];
}
$disponibilidadProfesionales = $_SESSION['disponibilidadProfesionales'];
// Inicializar la conexión a la base de datos
$conn = new mysqli("localhost", "u843239035_lauolgiati", "Santekinesio1", "u843239035_sante");
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar o crear una tabla mejorada de profesionales deshabilitados 
// que ahora guarda días específicos
$conn->query("CREATE TABLE IF NOT EXISTS profesionales_dias_deshabilitados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    profesional VARCHAR(255) NOT NULL,
    dia_semana VARCHAR(20) NOT NULL,
    deshabilitado TINYINT(1) DEFAULT 1,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY prof_dia (profesional, dia_semana)
)");

// Mantener la tabla original para compatibilidad
$conn->query("CREATE TABLE IF NOT EXISTS profesionales_deshabilitados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    profesional VARCHAR(255) NOT NULL,
    deshabilitado TINYINT(1) DEFAULT 1,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE(profesional)
)");

// Array con los días disponibles para seleccionar
$dias_semana_es = [
    'Monday' => 'Lunes',
    'Tuesday' => 'Martes',
    'Wednesday' => 'Miércoles',
    'Thursday' => 'Jueves',
    'Friday' => 'Viernes',
    'Saturday' => 'Sábado',
    'Sunday' => 'Domingo'
];

// Verificar días deshabilitados para este profesional
$dias_deshabilitados = [];
$query = $conn->prepare("SELECT dia_semana FROM profesionales_dias_deshabilitados WHERE profesional = ? AND deshabilitado = 1");
$query->bind_param("s", $profesional);
$query->execute();
$result = $query->get_result();
while ($row = $result->fetch_assoc()) {
    $dias_deshabilitados[] = $row['dia_semana'];
}

// Verificar si el profesional está completamente deshabilitado (para compatibilidad)
$query = $conn->prepare("SELECT deshabilitado FROM profesionales_deshabilitados WHERE profesional = ?");
$query->bind_param("s", $profesional);
$query->execute();
$result = $query->get_result();
$profesional_deshabilitado = false;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $profesional_deshabilitado = (bool)$row['deshabilitado'];
}

// FUNCIÓN ACTUALIZADA: deshabilitarDiaEspecifico
function deshabilitarDiaEspecifico($conn, $profesional, $dia_semana) {
    // Insertar o actualizar el estado del día específico en la base de datos
    $stmt = $conn->prepare("INSERT INTO profesionales_dias_deshabilitados (profesional, dia_semana, deshabilitado) 
                          VALUES (?, ?, 1) 
                          ON DUPLICATE KEY UPDATE deshabilitado = 1");
    $stmt->bind_param("ss", $profesional, $dia_semana);
    $stmt->execute();
}

// FUNCIÓN ACTUALIZADA: habilitarTodosLosDias
function habilitarTodosLosDias($conn, $profesional) {
    // Eliminar todos los días deshabilitados para este profesional
    $stmt = $conn->prepare("DELETE FROM profesionales_dias_deshabilitados WHERE profesional = ?");
    $stmt->bind_param("s", $profesional);
    $stmt->execute();
    
    // También limpiar la tabla antigua para compatibilidad
    $stmt = $conn->prepare("DELETE FROM profesionales_deshabilitados WHERE profesional = ?");
    $stmt->bind_param("s", $profesional);
    $stmt->execute();
}

// Modal para seleccionar días a deshabilitar
$modal_deshabilitar = false;

// Manejar las solicitudes POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mostrar_modal_deshabilitar'])) {
        $modal_deshabilitar = true;
    } elseif (isset($_POST['deshabilitar_dia']) && isset($_POST['dia_seleccionado'])) {
        $dia_seleccionado = $_POST['dia_seleccionado'];
        deshabilitarDiaEspecifico($conn, $profesional, $dia_seleccionado);
        echo "<script>alert('Día " . $dias_semana_es[$dia_seleccionado] . " deshabilitado.'); window.location.href='pacientes.php';</script>";
    } elseif (isset($_POST['habilitar'])) {
        habilitarTodosLosDias($conn, $profesional);
        echo "<script>alert('Todos los horarios habilitados.'); window.location.href='pacientes.php';</script>";
    } elseif (isset($_POST['asistencia_id'])) {
        $asistio = isset($_POST['asistio']) ? $_POST['asistio'] : 0;
        $asistencia_id = $_POST['asistencia_id'];
        $sql_update = "UPDATE turnos SET asistio = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param('ii', $asistio, $asistencia_id);
        if ($stmt->execute()) {
            echo "<script>alert('Estado de asistencia actualizado correctamente.'); window.location.href = 'pacientes.php" . (isset($_GET['view']) ? '?view=' . $_GET['view'] : '') . "';</script>";
        } else {
            echo "Error al actualizar el estado de asistencia: " . $conn->error;
        }
    }
}

// Establecer vista (día, semana, mes)
$view = isset($_GET['view']) ? $_GET['view'] : 'day'; // Por defecto, ver el día actual

// Establecer fecha de referencia
$fecha_actual = date('Y-m-d');
$dia_actual = date('j');
$mes_actual = date('m');
$anio_actual = date('Y');

// Sobrescribir con valores GET si existen
$mes = isset($_GET['mes']) ? $_GET['mes'] : $mes_actual;
$anio = isset($_GET['anio']) ? $_GET['anio'] : $anio_actual;
$dia = isset($_GET['dia']) ? $_GET['dia'] : $dia_actual;

// Calcular fechas para la vista seleccionada
switch ($view) {
    case 'day':
        // Para vista de día, usamos la fecha actual o la especificada
        $fecha_ini = "$anio-$mes-$dia";
        $fecha_fin = "$anio-$mes-$dia";
        break;
    case 'week':
        // Para vista de semana, calculamos el inicio y fin de la semana actual
        $fecha_referencia = "$anio-$mes-$dia";
        $num_dia_semana = date('w', strtotime($fecha_referencia));
        if ($num_dia_semana == 0) $num_dia_semana = 7; // Ajustar domingo a 7
        $inicio_semana = date('Y-m-d', strtotime("-" . ($num_dia_semana - 1) . " days", strtotime($fecha_referencia)));
        $fin_semana = date('Y-m-d', strtotime("+6 days", strtotime($inicio_semana)));
        $fecha_ini = $inicio_semana;
        $fecha_fin = $fin_semana;
        break;
    case 'month':
        // Para vista de mes, usamos todo el mes
        $fecha_ini = "$anio-$mes-01";
        $fecha_fin = date('Y-m-t', strtotime($fecha_ini));
        break;
    default:
        $fecha_ini = "$anio-$mes-$dia";
        $fecha_fin = "$anio-$mes-$dia";
}

// Variables para búsqueda
$busqueda_nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';
$busqueda_telefono = isset($_GET['telefono']) ? $_GET['telefono'] : '';

// Construir la consulta SQL con los filtros de búsqueda
$sql = "SELECT * FROM turnos WHERE profesional = ?";
$params = [$profesional];
$param_types = 's';

if (!empty($busqueda_nombre)) {
    $sql .= " AND nombre LIKE ?";
    $params[] = '%' . $busqueda_nombre . '%';
    $param_types .= 's';
}

if (!empty($busqueda_telefono)) {
    $sql .= " AND telefono LIKE ?";
    $params[] = '%' . $busqueda_telefono . '%';
    $param_types .= 's';
}

$sql .= " AND fecha BETWEEN ? AND ?";
$params[] = $fecha_ini;
$params[] = $fecha_fin;
$param_types .= 'ss';

$sql .= " ORDER BY fecha, hora";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$pacientes = $stmt->get_result();

// Verificar si la consulta fue exitosa
if ($pacientes === false) {
    echo "Error al obtener los pacientes: " . $conn->error;
    exit();
}

// Verificar los resultados obtenidos
$pacientes_array = $pacientes->fetch_all(MYSQLI_ASSOC);

// Agrupar pacientes por fecha
$pacientes_por_dia = [];
foreach ($pacientes_array as $paciente) {
    $fecha = $paciente['fecha'];
    if (!isset($pacientes_por_dia[$fecha])) {
        $pacientes_por_dia[$fecha] = [];
    }
    $pacientes_por_dia[$fecha][] = $paciente;
}

// Mapear días de la semana
$dias_semana = [
    'Monday' => 'Lunes',
    'Tuesday' => 'Martes',
    'Wednesday' => 'Miércoles',
    'Thursday' => 'Jueves',
    'Friday' => 'Viernes',
    'Saturday' => 'Sábado',
    'Sunday' => 'Domingo'
];

// Colores por servicio
$colores_servicio = [
    'Kinesiología' => '#E2C6C2',
    'Terapia Manual - RPG' => '#A6DA9C',
    'Drenaje Linfático' => '#BBFFFF',
    'Nutrición' => '#EE976A',
    'Traumatología' => '#A9B0F4',
    'Psicología' => '#f8c8dc',
];

// Funciones de navegación de fechas
function obtenerMesAnterior($mes, $anio) {
    if ($mes == 1) {
        return [12, $anio - 1];
    }
    return [$mes - 1, $anio];
}

function obtenerMesSiguiente($mes, $anio) {
    if ($mes == 12) {
        return [1, $anio + 1];
    }
    return [$mes + 1, $anio];
}

function obtenerDiaAnterior($dia, $mes, $anio) {
    $fecha = mktime(0, 0, 0, $mes, $dia, $anio);
    $fecha_anterior = strtotime('-1 day', $fecha);
    return [
        'dia' => date('j', $fecha_anterior),
        'mes' => date('n', $fecha_anterior),
        'anio' => date('Y', $fecha_anterior)
    ];
}

function obtenerDiaSiguiente($dia, $mes, $anio) {
    $fecha = mktime(0, 0, 0, $mes, $dia, $anio);
    $fecha_siguiente = strtotime('+1 day', $fecha);
    return [
        'dia' => date('j', $fecha_siguiente),
        'mes' => date('n', $fecha_siguiente),
        'anio' => date('Y', $fecha_siguiente)
    ];
}

function obtenerSemanaAnterior($dia, $mes, $anio) {
    $fecha = mktime(0, 0, 0, $mes, $dia, $anio);
    $fecha_anterior = strtotime('-7 days', $fecha);
    return [
        'dia' => date('j', $fecha_anterior),
        'mes' => date('n', $fecha_anterior),
        'anio' => date('Y', $fecha_anterior)
    ];
}

function obtenerSemanaSiguiente($dia, $mes, $anio) {
    $fecha = mktime(0, 0, 0, $mes, $dia, $anio);
    $fecha_siguiente = strtotime('+7 days', $fecha);
    return [
        'dia' => date('j', $fecha_siguiente),
        'mes' => date('n', $fecha_siguiente),
        'anio' => date('Y', $fecha_siguiente)
    ];
}

// Calcular fechas para la navegación
$dia_ant = obtenerDiaAnterior($dia, $mes, $anio);
$dia_sig = obtenerDiaSiguiente($dia, $mes, $anio);
$semana_ant = obtenerSemanaAnterior($dia, $mes, $anio);
$semana_sig = obtenerSemanaSiguiente($dia, $mes, $anio);
list($mes_anterior, $anio_anterior) = obtenerMesAnterior($mes, $anio);
list($mes_siguiente, $anio_siguiente) = obtenerMesSiguiente($mes, $anio);

// Obtener nombre del mes actual en español
setlocale(LC_TIME, 'es_ES.UTF-8', 'Spanish_Spain.1252');
$nombre_mes = date('F', mktime(0, 0, 0, $mes, 1, $anio));
$nombre_mes = str_replace(
    ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    $nombre_mes
);

// Función para obtener el nombre del día en español
function obtenerNombreDia($fecha) {
    $dias = [
        'Monday' => 'Lunes',
        'Tuesday' => 'Martes',
        'Wednesday' => 'Miércoles',
        'Thursday' => 'Jueves',
        'Friday' => 'Viernes',
        'Saturday' => 'Sábado',
        'Sunday' => 'Domingo'
    ];
    return $dias[date('l', strtotime($fecha))];
}

// Función para formatear fecha en español
function formatoFechaEspanol($fecha) {
    $meses = [
        '01' => 'Enero',
        '02' => 'Febrero',
        '03' => 'Marzo',
        '04' => 'Abril',
        '05' => 'Mayo',
        '06' => 'Junio',
        '07' => 'Julio',
        '08' => 'Agosto',
        '09' => 'Septiembre',
        '10' => 'Octubre',
        '11' => 'Noviembre',
        '12' => 'Diciembre'
    ];
    
    $partes = explode('-', $fecha);
    if (count($partes) !== 3) return $fecha;
    
    $dia = ltrim($partes[2], '0');
    $mes = $meses[$partes[1]];
    $anio = $partes[0];
    
    return "$dia de $mes de $anio";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Profesionales - Santé</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300&family=Noto+Sans&family=Poppins:wght@300&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/989f8affb2.js" crossorigin="anonymous"></script>
    <link rel="icon" href="../img/santeLogo.jpg">
    <style>
        body {
            background-color: #F6EBD5;
            font-family: 'Poppins', sans-serif;
        }
        
        .nav_container {
            background-color: #F6EBD5;
            color: white;
        }
        
        .logo {
            height: 50px;
        }
        
        h1 {
            color: #96B394;
            margin-bottom: 20px;
        }
        
        /* Selector de vistas */
        .view-selector {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .view-button {
            background-color: #f8f9fa;
            color: #333;
            border: 1px solid #ced4da;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .view-button:hover {
            background-color: #e9ecef;
        }
        
        .view-button.active {
            background-color: #96B394;
            color: white;
            border-color: #96B394;
        }
        
        /* Navegación de fechas */
        .date-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            background-color: #fff;
            padding: 10px 15px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .date-button {
            background-color: #96B394;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .date-button:hover {
            background-color: #7d9a7d;
            color: white;
        }
        
        .current-date {
            font-weight: bold;
            color: #333;
        }
        
        /* Buscar y botones de control */
        .search-form {
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .schedule-control {
            display: flex;
            justify-content: center;
            margin: 20px 0;
            gap: 10px;
        }
        
        .btn-primary, .add-patient-btn {
            background-color: #96B394;
            border-color: #96B394;
        }
        
        .btn-primary:hover, .add-patient-btn:hover {
            background-color: #7d9a7d;
            border-color: #7d9a7d;
        }
        
        .add-patient-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        /* Contenedor de pacientes */
        .day-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .day-header {
            background-color: #f8f9fa;
            display: flex;
            justify-content: space-between;
            padding: 12px 15px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .day-title {
            font-weight: bold;
            color: #333;
            margin: 0;
        }
        
        .time-slot {
            background-color: #f8f9fa;
            padding: 8px 15px;
            color: #555;
            font-weight: 500;
            margin-top: 10px;
            border-radius: 5px;
        }
        
        /* Tarjetas de pacientes */
        .patient-list {
            padding: 10px 15px;
        }
        
        .patient-card {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #f1f1f1;
            transition: all 0.2s;
        }
        
        .patient-card:last-child {
            border-bottom: none;
        }
        
        .patient-card:hover {
            background-color: #f9f9f9;
        }
        
        .patient-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .service-indicator {
            width: 6px;
            height: 30px;
            border-radius: 3px;
            flex-shrink: 0;
        }
        
        .patient-name {
            margin: 0;
            font-weight: 500;
            font-size: 1rem;
        }
        
        .patient-hour {
            color: #666;
            font-size: 0.875rem;
            margin: 0;
        }
        
        .attendance-form {
            display: flex;
            align-items: center;
        }
        
        .attendance-checkbox {
            margin-right: 8px;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .attendance-label {
            margin: 0;
            cursor: pointer;
            font-size: 0.875rem;
            color: #666;
        }
        
        /* Mensaje sin pacientes */
        .no-patients {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .date-navigation {
                flex-direction: column;
                gap: 10px;
            }
            
            .nav-buttons {
                display: flex;
                width: 100%;
                justify-content: space-between;
            }
            
            .search-form .row .col-12 {
                margin-bottom: 10px;
            }
        }
        
        /* Estilos para Modal */
        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1040;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-deshabilitar {
            background-color: white;
            border-radius: 10px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1050;
        }
        
        .modal-header {
            background-color: #96B394;
            color: white;
            padding: 15px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 15px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid #e9ecef;
        }
        
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }
        
        /* Estilos para los números de sesión */
        .session-number {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
            margin-left: 5px;
        }
        
        .session-first {
            background-color: #FFD700; /* Amarillo para la primera sesión */
            color: #333;
        }
        
        .session-tenth {
            background-color: #8B0000; /* Bordo para la décima sesión */
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container mt-4 mb-5">
        <h1 class="text-center">Panel de <?php echo $profesional; ?></h1>
        
        <!-- Selector de vista (día, semana, mes) -->
        <div class="view-selector">
            <a href="?view=day" class="view-button <?php echo $view === 'day' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-day"></i> Día
            </a>
            <a href="?view=week" class="view-button <?php echo $view === 'week' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-week"></i> Semana
            </a>
            <a href="?view=month" class="view-button <?php echo $view === 'month' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-alt"></i> Mes
            </a>
        </div>
        
        <!-- Navegación de fechas -->
        <div class="date-navigation">
            <?php if ($view === 'day'): ?>
                <a href="?view=day&dia=<?php echo $dia_ant['dia']; ?>&mes=<?php echo $dia_ant['mes']; ?>&anio=<?php echo $dia_ant['anio']; ?>" class="date-button">
                    <i class="fas fa-chevron-left"></i> Día anterior
                </a>
                <span class="current-date">
                    <?php echo formatoFechaEspanol($fecha_ini); ?>
                </span>
                <a href="?view=day&dia=<?php echo $dia_sig['dia']; ?>&mes=<?php echo $dia_sig['mes']; ?>&anio=<?php echo $dia_sig['anio']; ?>" class="date-button">
                    Día siguiente <i class="fas fa-chevron-right"></i>
                </a>
            <?php elseif ($view === 'week'): ?>
                <a href="?view=week&dia=<?php echo $semana_ant['dia']; ?>&mes=<?php echo $semana_ant['mes']; ?>&anio=<?php echo $semana_ant['anio']; ?>" class="date-button">
                    <i class="fas fa-chevron-left"></i> Semana anterior
                </a>
                <span class="current-date">
                    Semana: <?php echo date('d/m/Y', strtotime($fecha_ini)) . ' - ' . date('d/m/Y', strtotime($fecha_fin)); ?>
                </span>
                <a href="?view=week&dia=<?php echo $semana_sig['dia']; ?>&mes=<?php echo $semana_sig['mes']; ?>&anio=<?php echo $semana_sig['anio']; ?>" class="date-button">
                    Semana siguiente <i class="fas fa-chevron-right"></i>
                </a>
            <?php else: ?>
                <a href="?view=month&mes=<?php echo $mes_anterior; ?>&anio=<?php echo $anio_anterior; ?>" class="date-button">
                    <i class="fas fa-chevron-left"></i> Mes anterior
                </a>
                <span class="current-date">
                    <?php echo $nombre_mes . ' ' . $anio; ?>
                </span>
                <a href="?view=month&mes=<?php echo $mes_siguiente; ?>&anio=<?php echo $anio_siguiente; ?>" class="date-button">
                    Mes siguiente <i class="fas fa-chevron-right"></i>
                </a>
            <?php endif; ?>
        </div>
        
        <!-- Formulario de búsqueda -->
        <div class="search-form">
            <form method="GET" class="mb-0">
                <input type="hidden" name="view" value="<?php echo $view; ?>">
                <?php if ($view === 'day'): ?>
                    <input type="hidden" name="dia" value="<?php echo $dia; ?>">
                <?php endif; ?>
                <input type="hidden" name="mes" value="<?php echo $mes; ?>">
                <input type="hidden" name="anio" value="<?php echo $anio; ?>">
                
                <div class="row g-2 align-items-center">
                    <div class="col-12 col-md-5">
                        <input type="text" name="nombre" class="form-control" placeholder="Buscar por nombre" value="<?php echo htmlspecialchars($busqueda_nombre); ?>">
                    </div>
                    <div class="col-12 col-md-5">
                        <input type="text" name="telefono" class="form-control" placeholder="Buscar por teléfono" value="<?php echo htmlspecialchars($busqueda_telefono); ?>">
                    </div>
                    <div class="col-12 col-md-2">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-grow-1">Buscar</button>
                            <a href="?view=<?php echo $view; ?>" class="btn btn-secondary flex-grow-1">Limpiar</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Botón para agendar paciente -->
        <div class="d-flex justify-content-center mb-3">
            <a href="agendar_paciente.php" class="add-patient-btn">
                <i class="fas fa-user-plus"></i> Agendar nuevo paciente
            </a>
        </div>
        
        <!-- Control de habilitación de horarios -->
        <div class="schedule-control">
            <form method="POST" action="" class="d-inline-block">
                <button type="submit" name="mostrar_modal_deshabilitar" class="btn btn-danger px-4 py-2">
                    <i class="fas fa-ban me-2"></i>Deshabilitar día específico
                </button>
            </form>
            
            <form method="POST" action="" class="d-inline-block">
                <button type="submit" name="habilitar" class="btn btn-success px-4 py-2">
                    <i class="fas fa-check-circle me-2"></i>Habilitar todos los días
                </button>
            </form>
        </div>
        
        <!-- Listado de pacientes -->
        <?php if (empty($pacientes_por_dia)): ?>
            <div class="day-container">
                <div class="no-patients py-4">
                    <i class="fas fa-calendar-times fa-3x mb-3 text-muted"></i>
                    <h4>No hay pacientes para mostrar</h4>
                    <p class="text-muted">No se encontraron pacientes programados para el período seleccionado.</p>
                </div>
            </div>
        <?php else: ?>
            <?php 
            // Ordenar fechas cronológicamente
            ksort($pacientes_por_dia);
            
            foreach ($pacientes_por_dia as $fecha => $pacientes_fecha): 
                $diaSemana = obtenerNombreDia($fecha);
                $fechaFormateada = date('d/m/Y', strtotime($fecha));
                
                // Ordenar pacientes por hora
                usort($pacientes_fecha, function($a, $b) {
                    return strtotime($a['hora']) - strtotime($b['hora']);
                });
                
                // Agrupar pacientes por hora para esta fecha
                $pacientes_por_hora = [];
                foreach ($pacientes_fecha as $paciente) {
                    $hora = $paciente['hora'];
                    if (!isset($pacientes_por_hora[$hora])) {
                        $pacientes_por_hora[$hora] = [];
                    }
                    $pacientes_por_hora[$hora][] = $paciente;
                }
            ?>
                <div class="day-container">
                    <div class="day-header">
                        <h3 class="day-title"><?php echo $diaSemana; ?></h3>
                        <span><?php echo $fechaFormateada; ?></span>
                    </div>
                    
                    <div class="patient-list">
                        <?php foreach ($pacientes_por_hora as $hora => $pacientes_hora): ?>
                            <div class="time-slot">
                                <i class="far fa-clock me-2"></i><?php echo date('H:i', strtotime($hora)); ?>
                            </div>
                            
                            <?php foreach ($pacientes_hora as $paciente): 
                                // Determinar la clase CSS para el número de sesión
                                $session_class = '';
                                $session_number = isset($paciente['numero_sesion']) ? (int)$paciente['numero_sesion'] : 0;
                                
                                if ($session_number === 1) {
                                    $session_class = 'session-first';
                                } elseif ($session_number === 10) {
                                    $session_class = 'session-tenth';
                                }
                            ?>
                                <div class="patient-card" onclick="window.location.href='diagnostico.php?id=<?php echo $paciente['id']; ?>'" style="cursor: pointer;">
                                    <div class="patient-info">
                                        <div class="service-indicator" style="background-color: <?php echo isset($colores_servicio[$paciente['servicio']]) ? $colores_servicio[$paciente['servicio']] : '#ddd'; ?>"></div>
                                        <div>
                                            <h5 class="patient-name">
                                                <?php echo htmlspecialchars($paciente['nombre']); ?>
                                                <?php if (isset($paciente['numero_sesion']) && !empty($paciente['numero_sesion'])): ?>
                                                    <span class="session-number <?php echo $session_class; ?>">
                                                        <?php echo $paciente['numero_sesion']; ?>
                                                    </span>
                                                <?php endif; ?>
                                            </h5>
                                            <p class="patient-hour"><?php echo $paciente['servicio']; ?></p>
                                        </div>
                                    </div>
                                    <form method="POST" class="attendance-form">
                                        <input type="hidden" name="asistencia_id" value="<?php echo $paciente['id']; ?>">
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <div>
                                                <input type="radio" name="asistio" value="1" class="attendance-checkbox" id="asistio_si_<?php echo $paciente['id']; ?>" 
                                                    <?php echo isset($paciente['asistio']) && $paciente['asistio'] == 1 ? 'checked' : ''; ?> 
                                                    onchange="this.form.submit()">
                                                <label for="asistio_si_<?php echo $paciente['id']; ?>" style="font-size: 0.8rem; margin-left: 3px;">
                                                    Asistió
                                                </label>
                                            </div>
                                            <div>
                                                <input type="radio" name="asistio" value="0" class="attendance-checkbox" id="asistio_no_<?php echo $paciente['id']; ?>" 
                                                    <?php echo isset($paciente['asistio']) && $paciente['asistio'] == 0 ? 'checked' : ''; ?> 
                                                    onchange="this.form.submit()">
                                                <label for="asistio_no_<?php echo $paciente['id']; ?>" style="font-size: 0.8rem; margin-left: 3px;">
                                                    No asistió
                                                </label>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Modal para seleccionar días a deshabilitar -->
    <?php if ($modal_deshabilitar): ?>
    <div class="modal-backdrop">
        <div class="modal-deshabilitar">
            <div class="modal-header">
                <h5>Seleccionar día a deshabilitar</h5>
                <button type="button" class="close-btn" onclick="window.location.href='pacientes.php'">×</button>
            </div>
            <div class="modal-body">
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="dia_seleccionado" class="form-label">Seleccione el día que desea deshabilitar:</label>
                        <select class="form-select" id="dia_seleccionado" name="dia_seleccionado" required>
                            <?php foreach ($dias_semana_es as $dia_en => $dia_es): ?>
                                <?php if (isset($disponibilidadProfesionales[$profesional][$dia_en]) || 
                                          isset($disponibilidadProfesionales[$profesional][$dia_en . ' (Terapia Manual - RPG)'])): ?>
                                    <option value="<?php echo $dia_en; ?>" <?php echo in_array($dia_en, $dias_deshabilitados) ? 'disabled' : ''; ?>>
                                        <?php echo $dia_es; ?> <?php echo in_array($dia_en, $dias_deshabilitados) ? '(Ya deshabilitado)' : ''; ?>
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="window.location.href='pacientes.php'">Cancelar</button>
                        <button type="submit" name="deshabilitar_dia" class="btn btn-danger">Deshabilitar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        // Actualizar etiqueta de asistencia cuando se cambia el checkbox
        document.querySelectorAll('.attendance-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const label = this.nextElementSibling;
                label.textContent = this.checked ? 'Asistió' : 'No asistió';
            });
        });

        // Añadir efecto hover a las tarjetas de pacientes
        document.querySelectorAll('.patient-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f9f9f9';
            });
            card.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    </script>
</body>
</html>