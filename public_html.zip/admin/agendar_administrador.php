<?php
session_start([
    'cookie_lifetime' => 0,
]);

// Verificar si el usuario está logueado como administrador
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: index.php');
    exit();
}

// Definir los profesionales por servicio
$profesionales_por_servicio = [
    'Nutrición' => ['Maria Paz'],
    'Terapia Manual - RPG' => ['Lucia Foricher', 'Mariana Ilari'],
    'Traumatología' => ['Miriam Rossello'],
    'Drenaje Linfático' => ['Florencia Goñi', 'Constanza Marinello'],
    'Kinesiología' => ['Lucia Foricher', 'Alejandro Perez','Hernan Lopez', 'Mauro Robert', 'Gastón Olgiati', 'German Fernandez','Melina Thome'],
    'Psicología' => ['Leila Heguilein'],
];

// Definir los horarios disponibles por profesional
$horarios_profesionales = [
    'Lucia Foricher' => [
        'Kinesiología' => ['08:00', '09:00', '10:00', '11:00'],
        'Terapia Manual - RPG' => ['16:00', '17:00', '18:00', '19:00', '11:00', '12:00', '13:00', '14:00', '15:00']
    ],
    'Mariana Ilari' => [
        'Terapia Manual - RPG' => ['08:30', '09:30', '10:30', '11:30', '17:00', '18:00']
    ],
    'Alejandro Perez' => [
        'Kinesiología' => ['08:00', '09:00', '10:00', '11:00']
    ],
    'Hernan Lopez' => [
        'Kinesiología' => ['08:00', '09:00', '10:00', '11:00', '12:00']
    ],
    'Mauro Robert' => [
        'Kinesiología' => ['13:00', '14:00', '15:00', '16:00']
    ],
    'Gastón Olgiati' => [
        'Kinesiología' => ['13:00', '14:00', '15:00', '16:00']
    ],
    'German Fernandez' => [
        'Kinesiología' => ['17:30', '18:30', '19:30']
    ],
    'Melina Thome' => [
        'Kinesiología' => ['17:00', '18:00', '19:00']
    ],
    'Maria Paz' => [
        'Nutrición' => ['17:00', '18:00', '19:00', '12:00']
    ],
    'Miriam Rossello' => [
        'Traumatología' => ['08:00', '08:15', '08:30', '08:45', '09:00', '09:15', '09:30', '09:45', '10:00', '10:15', '10:30', '10:45', '11:00', '11:15', '11:30', '11:45']
    ],
    'Florencia Goñi' => [
        'Drenaje Linfático' => ['17:00', '18:00']
    ],
    'Constanza Marinello' => [
        'Drenaje Linfático' => ['15:00', '16:00', '17:00', '13:00', '14:00']
    ],
    'Leila Heguilein' => [
        'Psicología' => ['17:00', '18:00', '19:00', '20:00']
    ]
];

// Procesar el formulario cuando se envía
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Conectar a la base de datos
    $conn = new mysqli("localhost", "u843239035_lauolgiati", "Santekinesio1", "u843239035_sante");
    if ($conn->connect_error) {
        $error_message = "Error de conexión: " . $conn->connect_error;
    } else {
        // Recoger y limpiar los datos del formulario
        $servicio = $conn->real_escape_string($_POST['servicio']);
        $profesional = $conn->real_escape_string($_POST['profesional']);
        $fecha = $conn->real_escape_string($_POST['fecha']);
        $hora = $conn->real_escape_string($_POST['hora']);
        $nombre = $conn->real_escape_string($_POST['nombre']);
        $telefono = $conn->real_escape_string($_POST['telefono']);
        $gmail = $conn->real_escape_string($_POST['gmail']);
        $obra_social = $conn->real_escape_string($_POST['obra_social']);
        
        // Verificar si el día está deshabilitado para este profesional
        $diaSemana = date('l', strtotime($fecha)); // Obtener el día de la semana (en inglés)
        $stmt = $conn->prepare("SELECT COUNT(*) FROM profesionales_dias_deshabilitados WHERE profesional = ? AND dia_semana = ? AND deshabilitado = 1");
        $stmt->bind_param("ss", $profesional, $diaSemana);
        $stmt->execute();
        $stmt->bind_result($dia_deshabilitado);
        $stmt->fetch();
        $stmt->close();
        
        if ($dia_deshabilitado > 0) {
            $error_message = "El profesional no está disponible en el día seleccionado.";
        } else {
            // Verificar si el profesional está completamente deshabilitado
            $stmt = $conn->prepare("SELECT COUNT(*) FROM profesionales_deshabilitados WHERE profesional = ? AND deshabilitado = 1");
            $stmt->bind_param("s", $profesional);
            $stmt->execute();
            $stmt->bind_result($prof_deshabilitado);
            $stmt->fetch();
            $stmt->close();
            
            if ($prof_deshabilitado > 0) {
                $error_message = "El profesional no está disponible actualmente.";
            } else {
                // Verificar la cantidad de turnos en la misma hora para Kinesiología
                if ($servicio === 'Kinesiología') {
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM turnos WHERE servicio = 'Kinesiología' AND profesional = ? AND fecha = ? AND hora = ?");
                    $stmt->bind_param("sss", $profesional, $fecha, $hora);
                    $stmt->execute();
                    $stmt->bind_result($num_pacientes);
                    $stmt->fetch();
                    $stmt->close();
                    
                    if ($num_pacientes >= 4) {
                        $error_message = "No puedes registrar más de 4 pacientes en la misma hora para Kinesiología.";
                    }
                } else {
                    // Para otros servicios, verificar si ya existe un turno en la misma hora
                    $stmt = $conn->prepare("SELECT COUNT(*) FROM turnos WHERE profesional = ? AND fecha = ? AND hora = ? AND servicio = ?");
                    $stmt->bind_param("ssss", $profesional, $fecha, $hora, $servicio);
                    $stmt->execute();
                    $stmt->bind_result($turno_existente);
                    $stmt->fetch();
                    $stmt->close();
                    
                    if ($turno_existente > 0) {
                        $error_message = "Ya existe un turno para este profesional, fecha y hora.";
                    }
                }
                
                // Si no hay errores, proceder a registrar el turno
                if (empty($error_message)) {
                    // Insertar el nuevo turno en la base de datos
                    $stmt = $conn->prepare("INSERT INTO turnos (servicio, profesional, fecha, hora, nombre, telefono, gmail, obra_social, numero_sesion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");
                    $stmt->bind_param("ssssssss", $servicio, $profesional, $fecha, $hora, $nombre, $telefono, $gmail, $obra_social);
                    
                    if ($stmt->execute()) {
                        $success_message = "Paciente registrado con éxito.";
                        
                        // Enviar email de confirmación
                        // Nota: Este bloque está comentado porque puede requerir configuración adicional
                        /*
                        try {
                            // Código para enviar email...
                        } catch (Exception $e) {
                            // Manejar error de envío...
                        }
                        */
                    } else {
                        $error_message = "Error al registrar el paciente: " . $stmt->error;
                    }
                    $stmt->close();
                }
            }
        }
        
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Paciente</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="icon" href="../img/santeLogo.jpg">
    <script src="../js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300&family=Poppins:wght@300&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #F6EBD5;
            font-family: 'Poppins', sans-serif;
        }

        .btn_horarios{
            background-color: #96B394;
            border: none;
            padding: 8px;
            cursor: pointer;
            border-radius: 10px !important;
            position: relative;
            bottom: 9px;
        }

        .btn_horarios a{
            color: white;
            text-decoration: none;
        }

        .content {
            padding: 20px;
            margin: auto;
            width: 90%;
            max-width: 600px;
        }
        h1 {
            color: #96B394;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-group button {
            background-color: #96B394;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .form-group button:hover {
            background-color: #7d9a7d;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>Agendar Paciente</h1>
        <div class="form-container">
            <?php if (!empty($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success_message)): ?>
                <div class="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <form id="agendarPacienteForm" method="POST" action="">
                <button class="btn_horarios"><a href="administrador.php">Volver</a></button>
                <div class="form-group">
                    <label for="servicio">Servicio</label>
                    <select id="servicio" name="servicio" class="form-control" required>
                        <option value="">Seleccione un servicio</option>
                        <option value="Kinesiología">Kinesiología</option>
                        <option value="Terapia Manual - RPG">Terapia Manual - RPG</option>
                        <option value="Drenaje Linfático">Drenaje Linfático</option>
                        <option value="Nutrición">Nutrición</option>
                        <option value="Traumatología">Traumatología</option>
                        <option value="Psicología">Psicología</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="profesional">Profesional</label>
                    <select id="profesional" name="profesional" class="form-control" required>
                        <option value="">Seleccione un profesional</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <input type="text" id="fecha" name="fecha" class="form-control fecha" placeholder="Seleccione la fecha" required>
                </div>
                <div class="form-group">
                    <label for="hora">Hora</label>
                    <select id="hora" name="hora" class="form-control" required>
                        <option value="">Seleccione una hora</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="nombre">Nombre completo</label>
                    <input type="text" id="nombre" name="nombre" class="form-control" placeholder="Nombre completo" required>
                </div>
                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" name="telefono" class="form-control" placeholder="Teléfono" required>
                </div>
                <div class="form-group">
                    <label for="gmail">Gmail</label>
                    <input type="email" id="gmail" name="gmail" class="form-control" placeholder="Gmail" required>
                </div>
                <div class="form-group">
                    <label for="obra_social">Obra Social</label>
                    <input type="text" id="obra_social" name="obra_social" class="form-control" placeholder="Obra Social" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Registrar Paciente</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr('#fecha', {
                altInput: true,
                altFormat: "F j, Y",
                dateFormat: "Y-m-d",
                minDate: "today"
            });
            
            // Definir los profesionales por servicio (como en PHP)
            const profesionalesPorServicio = <?php echo json_encode($profesionales_por_servicio); ?>;
            
            // Definir los horarios por profesional y servicio (como en PHP)
            const horariosProfesionales = <?php echo json_encode($horarios_profesionales); ?>;
            
            // Referencias a los elementos del DOM
            const servicioSelect = document.getElementById('servicio');
            const profesionalSelect = document.getElementById('profesional');
            const horaSelect = document.getElementById('hora');
            
            // Escuchar cambios en el servicio seleccionado
            servicioSelect.addEventListener('change', function() {
                const servicioSeleccionado = this.value;
                
                // Limpiar el select de profesionales
                profesionalSelect.innerHTML = '<option value="">Seleccione un profesional</option>';
                horaSelect.innerHTML = '<option value="">Seleccione una hora</option>';
                
                // Si se seleccionó un servicio, cargar los profesionales correspondientes
                if (servicioSeleccionado && profesionalesPorServicio[servicioSeleccionado]) {
                    profesionalesPorServicio[servicioSeleccionado].forEach(function(profesional) {
                        const option = document.createElement('option');
                        option.value = profesional;
                        option.textContent = profesional;
                        profesionalSelect.appendChild(option);
                    });
                }
            });
            
            // Escuchar cambios en el profesional seleccionado
            profesionalSelect.addEventListener('change', function() {
                const profesionalSeleccionado = this.value;
                const servicioSeleccionado = servicioSelect.value;
                
                // Limpiar el select de horas
                horaSelect.innerHTML = '<option value="">Seleccione una hora</option>';
                
                // Si se seleccionó un profesional y un servicio, cargar las horas correspondientes
                if (profesionalSeleccionado && servicioSeleccionado && 
                    horariosProfesionales[profesionalSeleccionado] && 
                    horariosProfesionales[profesionalSeleccionado][servicioSeleccionado]) {
                    
                    horariosProfesionales[profesionalSeleccionado][servicioSeleccionado].forEach(function(hora) {
                        const option = document.createElement('option');
                        option.value = hora;
                        option.textContent = hora;
                        horaSelect.appendChild(option);
                    });
                }
            });
        });
    </script>
</body>
</html>