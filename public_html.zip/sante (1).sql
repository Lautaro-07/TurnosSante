-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-04-2025 a las 19:28:39
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sante`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidad`
--

CREATE TABLE `disponibilidad` (
  `id` int(11) NOT NULL,
  `nombre_profesional` varchar(100) NOT NULL,
  `dia_semana` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `disponibilidad`
--

INSERT INTO `disponibilidad` (`id`, `nombre_profesional`, `dia_semana`, `hora_inicio`, `hora_fin`) VALUES
(47, 'Lucia Foricher', 'Monday', '08:00:00', '12:00:00'),
(48, 'Lucia Foricher (Terapia Manual-RPG)', 'Monday', '16:00:00', '20:00:00'),
(49, 'Mauro Robert', 'Monday', '13:00:00', '17:00:00'),
(50, 'Gastón Fernandez Vita', 'Monday', '17:30:00', '20:30:00'),
(51, 'Gastón Olgiati', 'Monday', '13:00:00', '17:00:00'),
(52, 'Hernán López', 'Tuesday', '08:00:00', '12:00:00'),
(53, 'Alejandro Perez ', 'Monday', '08:00:00', '12:00:00'),
(54, 'Melina Thome', 'Monday', '17:00:00', '20:00:00'),
(55, 'Maria Paz Ruilopez', 'Wednesday', '17:00:00', '20:00:00'),
(56, 'Miriam Rossello', 'Tuesday', '08:00:00', '12:00:00'),
(57, 'Florencia Goñi', 'Monday', '17:00:00', '19:00:00'),
(58, 'Constanza Marinello', 'Monday', '13:00:00', '17:00:00'),
(59, 'Mariana Ilari', 'Thursday', '08:30:00', '18:00:00'),
(60, 'Maria Paz', 'Wednesday', '17:00:00', '19:00:00'),
(61, 'Leila Heguilein', 'Tuesday', '17:00:00', '20:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagenes_diagnostico`
--

CREATE TABLE `imagenes_diagnostico` (
  `id` int(11) NOT NULL,
  `turno_id` int(11) NOT NULL,
  `imagen` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `precio_servicios`
--

CREATE TABLE `precio_servicios` (
  `id` int(11) NOT NULL,
  `servicio` varchar(255) NOT NULL,
  `precio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `precio_servicios`
--

INSERT INTO `precio_servicios` (`id`, `servicio`, `precio`) VALUES
(1, 'Drenaje Linfático', 12000),
(2, 'Kinesiología', 11000),
(3, 'Kinesiología Dermatofuncional', 13000),
(4, 'Nutrición', 10000),
(5, 'Terapia Manual - RPG', 12500),
(6, 'Traumatología', 14000),
(7, 'Psicología', 20000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turnos`
--

CREATE TABLE `turnos` (
  `id` int(11) NOT NULL,
  `servicio` varchar(100) NOT NULL,
  `profesional` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `gmail` varchar(200) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `obra_social` varchar(100) DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  `numero_sesion` int(11) DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `imagen_diagnostico` longblob DEFAULT NULL,
  `asistio` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `turnos`
--

INSERT INTO `turnos` (`id`, `servicio`, `profesional`, `fecha`, `hora`, `nombre`, `gmail`, `telefono`, `obra_social`, `comentarios`, `numero_sesion`, `diagnostico`, `imagen_diagnostico`, `asistio`) VALUES
(84, 'Traumatología', 'Miriam', '2025-03-20', '11:00:00', 'Lautaro', 'Adriana@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 0),
(85, 'Kinesiología', 'Lucia Foricher', '2025-03-21', '09:00:00', 'Lautaro', 'shopii.versee@gmail.com', '02915323692', 'PAMI', NULL, 1, NULL, NULL, 0),
(86, 'Kinesiología', 'Mauro Robert', '2025-03-19', '16:00:00', 'Mauro', 'mauro@gmail.com', '02915323692', 'PAMI', NULL, 1, NULL, NULL, 0),
(87, 'Kinesiología', 'Gastón Olgiati', '2025-03-19', '16:00:00', 'Lautaro', 'ricardo@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 1),
(88, 'Drenaje Linfático', 'Florencia Goñi', '2025-03-20', '17:00:00', 'Lautaro', 'ricardo@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 0),
(89, 'Drenaje Linfático', 'Lucia Foricher', '2025-03-21', '10:00:00', 'Carlos', 'Adriana@gmail.com', '02915323694', 'IOMA', NULL, 1, NULL, NULL, 0),
(91, 'Kinesiología', 'Lucia Foricher', '2025-03-28', '08:00:00', 'Lautaro', 'oligiatielizondo@gmail.com', '02914125043', 'IOMA', NULL, 1, NULL, NULL, 0),
(99, 'Terapia Manual - RPG', 'Lucia Foricher', '2025-03-28', '15:00:00', 'Lautaro', 'oligiatielizondo@gmail.com', '02914125043', 'IOMA', NULL, 1, NULL, NULL, 1),
(100, 'Kinesiología', 'Hernan Lopez', '2025-04-01', '09:00:00', 'Lautaro', 'lucia@gmail.com', '02914125043', 'IOMA', NULL, 1, NULL, NULL, 0),
(101, 'Kinesiología', 'Melina Thome', '2025-04-04', '18:00:00', 'Lautaro', 'Marcos@gmail.com', '02915323692', 'PAMI', NULL, 1, NULL, NULL, 1),
(102, 'Kinesiología', 'Alejandro Perez', '2025-04-02', '09:00:00', 'Lautaro', 'oligiatielizondo@gmail.com', '02915323692', 'PAMI', NULL, 1, NULL, NULL, 0),
(103, 'Kinesiología', 'Lucia Foricher', '2025-04-02', '09:00:00', 'Lautaro', 'shopii.versee@gmail.com', '02915323692', 'IOMA', NULL, 2, NULL, NULL, 0),
(104, 'Terapia Manual - RPG', 'Lucia Foricher', '2025-04-03', '15:00:00', 'Lautaro', 'Adriana@gmail.com', '02915323692', 'IOMA', '', 1, NULL, NULL, 0),
(110, 'Terapia Manual - RPG', 'Mariana Ilari', '2025-04-09', '11:30:00', 'Lautaro', 'oligiatielizondo@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 0),
(111, 'Kinesiología', 'Lucia Foricher', '2025-04-07', '11:00:00', 'Jaun', 'oligiatielizondo@gmail.com', '2914125043', 'IOMA', NULL, NULL, NULL, NULL, 0),
(112, 'Psicología', 'Leila Heguilein', '2025-04-09', '20:00:00', 'Lautaro', 'oligiatielizondo@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 0),
(113, 'Nutrición', 'Maria Paz', '2025-04-09', '18:00:00', 'Lautaro', 'shopii.versee@gmail.com', '02915323692', 'IOMA', NULL, 1, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `email`, `pass`, `name`) VALUES
(1, 'luciaforicher@gmail.com', 'luciaforicher', 'Lucia Foricher'),
(2, 'florencia@gmail.com', 'florencia', 'Florencia Goñi'),
(3, 'constanza@gmail.com', 'constanza', 'Constanza Marinello\r\n'),
(4, 'mariapaz@gmail.com', 'mariapaz', 'Maria Paz'),
(5, 'mariana@gmail.com', 'mariana', 'Mariana Ilari'),
(6, 'miriam@gmail.com', 'miriam', 'Miriam Rossello'),
(7, 'maurorobert@gmail.com', 'maurorobert', 'Mauro Robert'),
(8, 'germanfernandez@gmail.com', 'germanfernandez', 'German Fernandez'),
(9, 'gastonolgiati@gmail.com', 'gastonolgiati', 'Gastón Olgiati'),
(10, 'melinathome@gmail.com', 'melinathome', 'Melina Thome'),
(11, 'hernanlopez@gmail.com', 'hernanlopez', 'Hernán López'),
(12, 'alejandroperez@gmail.com', 'alejandroperez', 'Alejandro Perez'),
(15, 'administrador@gmail.com', 'administrador', 'administrador\r\n'),
(16, 'leila@gmail.com', 'leila', 'Leila Heguilein');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `disponibilidad`
--
ALTER TABLE `disponibilidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `imagenes_diagnostico`
--
ALTER TABLE `imagenes_diagnostico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `turno_id` (`turno_id`);

--
-- Indices de la tabla `precio_servicios`
--
ALTER TABLE `precio_servicios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `servicio` (`servicio`);

--
-- Indices de la tabla `turnos`
--
ALTER TABLE `turnos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `disponibilidad`
--
ALTER TABLE `disponibilidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT de la tabla `imagenes_diagnostico`
--
ALTER TABLE `imagenes_diagnostico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `precio_servicios`
--
ALTER TABLE `precio_servicios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `turnos`
--
ALTER TABLE `turnos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `imagenes_diagnostico`
--
ALTER TABLE `imagenes_diagnostico`
  ADD CONSTRAINT `imagenes_diagnostico_ibfk_1` FOREIGN KEY (`turno_id`) REFERENCES `turnos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
